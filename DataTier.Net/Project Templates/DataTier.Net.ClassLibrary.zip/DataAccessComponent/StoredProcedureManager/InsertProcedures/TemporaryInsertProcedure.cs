

#region using statements

using System;

#endregion


namespace $safeprojectname$.StoredProcedureManager.InsertProcedures
{

    #region class TemporaryInsertProcedure
    /// <summary>
    /// This is a temporary class that can be removed
    /// after a IntMap project has Insert Procedures.
    /// </summary>
    class TemporaryInsertProcedure
    {
        /*
         
         **********************************
         **  This class is only here so the 
         **  project compiles with the 
         **  correct using statements.
         ********************************
          
        */

    }
    #endregion

}
