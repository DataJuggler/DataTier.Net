

#region using statements

using System;
using $safeprojectname$.Enumerations;

#endregion

namespace $safeprojectname$.Parsers
{

    #region class Parser
    /// <summary>
    /// This class parses the enumerations in the 
    /// Enumerations Folder
    /// </summary>
    public class Parser
    {

        #region Static Methods

        // Add Any Custom Parser Methods Here

        #endregion

    }
    #endregion

}
